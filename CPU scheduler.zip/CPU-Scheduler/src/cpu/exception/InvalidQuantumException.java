package cpu.exception;

public class InvalidQuantumException extends Exception {
    public InvalidQuantumException(String msg) {
        super(msg);
    }
}