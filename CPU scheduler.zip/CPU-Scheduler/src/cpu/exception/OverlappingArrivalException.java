package cpu.exception;

public class OverlappingArrivalException extends Exception {
    public OverlappingArrivalException(String msg) {
        super(msg);
    }
}
