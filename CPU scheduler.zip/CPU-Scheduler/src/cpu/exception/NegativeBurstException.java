package cpu.exception;

public class NegativeBurstException extends Exception {
    public NegativeBurstException(String msg) {
        super(msg);
    }
}